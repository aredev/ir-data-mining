from django.apps import AppConfig


class PapersConfig(AppConfig):
    name = 'papers'
